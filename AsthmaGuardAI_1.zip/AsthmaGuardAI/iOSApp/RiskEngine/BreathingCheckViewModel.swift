import Foundation
import Combine

/// Backs both the Dashboard and "Check My Breathing" flow. MVVM: views bind
/// to @Published state here rather than touching HealthKit/RiskScoringEngine
/// directly.
final class BreathingCheckViewModel: ObservableObject {

    @Published var symptomCheck = SymptomCheck()
    @Published var latestResult: RiskResult?
    @Published var isChecking = false

    private let riskEngine = RiskScoringEngine()
    private let health = HealthKitManager.shared
    private let environmentService = EnvironmentalDataService()
    private var profile: UserProfile { PersistenceStore.shared.loadProfile() }

    func runCheck(completion: @escaping (RiskResult) -> Void) {
        isChecking = true
        health.fetchSnapshot { [weak self] vitals in
            guard let self else { return }
            self.environmentService.fetchCurrentContext { environment in
                let result = self.riskEngine.evaluate(
                    symptoms: self.symptomCheck,
                    vitals: vitals,
                    environment: environment,
                    profile: self.profile)

                PersistenceStore.shared.appendRiskResult(result)
                DispatchQueue.main.async {
                    self.latestResult = result
                    self.isChecking = false
                    completion(result)
                }
            }
        }
    }

    func resetQuestionnaire() {
        symptomCheck = SymptomCheck()
    }
}
