import Foundation

/// All user-facing risk wording lives here so it's easy to audit — the app
/// must never claim to diagnose an asthma attack. It reports possible
/// symptoms and encourages the user to follow their own action plan.
enum AppCopy {
    static func message(for level: RiskLevel) -> String {
        switch level {
        case .low:
            return "No concerning symptoms detected right now."
        case .moderate:
            return "Some possible asthma symptoms detected. Consider resting and monitoring."
        case .high:
            return "Possible asthma symptoms detected. Consider using your rescue inhaler and following your asthma action plan."
        case .emergency:
            return "Possible severe asthma symptoms detected. Use your rescue inhaler now if you haven't, and seek emergency help if you don't improve quickly."
        }
    }

    static let disclaimer = "AsthmaGuard AI does not diagnose asthma attacks and is not a substitute for professional medical care. If you are in doubt, use your rescue inhaler and/or seek emergency help."

    static let aiAssistantDisclaimer = "This assistant can help explain symptoms and your action plan, but it does not replace your doctor."
}

enum AppConstants {
    static let minimumConsecutiveHighReadings = 2   // hysteresis for auto-detection
    static let escalationWindowSeconds: TimeInterval = 30
    static let defaultSpo2AlertThreshold = 0.92
    static let defaultSpo2WatchThreshold = 0.94
}
