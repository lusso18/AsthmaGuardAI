import Foundation

/// Deliberately not "attack detected" — wording stays at "possible symptoms"
/// per the app's safety guidelines. See Constants/AppCopy.swift.
enum RiskLevel: Int, Codable, Comparable, CaseIterable {
    case low = 0
    case moderate = 1
    case high = 2
    case emergency = 3

    static func < (lhs: RiskLevel, rhs: RiskLevel) -> Bool { lhs.rawValue < rhs.rawValue }

    var label: String {
        switch self {
        case .low: return "Low"
        case .moderate: return "Moderate"
        case .high: return "High"
        case .emergency: return "Emergency"
        }
    }
}

/// Answers from the manual "Check My Breathing" symptom questionnaire.
struct SymptomCheck: Codable, Equatable {
    var shortnessOfBreath: Int = 0     // 0-3 scale
    var coughing: Int = 0
    var wheezing: Int = 0
    var chestTightness: Int = 0
    var difficultySpeaking: Bool = false
    var lipsOrFingersBluish: Bool = false   // strong emergency signal if true
    var timestamp: Date = Date()

    var subjectiveSeverityScore: Int {
        shortnessOfBreath + coughing + wheezing + chestTightness
            + (difficultySpeaking ? 3 : 0)
            + (lipsOrFingersBluish ? 6 : 0)
    }
}

/// Snapshot of vitals pulled from HealthKit/watch at check time.
struct VitalsSnapshot: Codable, Equatable {
    var spo2: Double? = nil                 // fraction, e.g. 0.94
    var heartRate: Double? = nil
    var restingHeartRate: Double? = nil
    var respiratoryRate: Double? = nil
    var heartRateVariability: Double? = nil // HRV in ms (SDNN)
    var sleepQualityScore: Double? = nil    // 0-1, derived from sleep analysis
    var stepCountToday: Double? = nil
}

/// Optional environmental context, filled in by placeholder services.
struct EnvironmentalContext: Codable, Equatable {
    var pollenIndex: Double? = nil          // 0-10 scale
    var airQualityIndex: Double? = nil      // standard AQI
    var temperatureF: Double? = nil
    var isColdAirTrigger: Bool = false
}

/// Full result of a risk evaluation, ready to show on the Result screen and
/// to save into history / include in a doctor report.
struct RiskResult: Codable, Identifiable, Equatable {
    var id: UUID = UUID()
    var timestamp: Date = Date()
    var riskLevel: RiskLevel
    var symptomCheck: SymptomCheck?
    var vitals: VitalsSnapshot?
    var environment: EnvironmentalContext?
    var contributingFactors: [String]      // human-readable reasons, e.g. "SpO2 below 92%"
    var message: String                    // safe wording, e.g. "Possible asthma symptoms detected."
}
