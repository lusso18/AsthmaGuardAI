import WatchConnectivity
import UserNotifications

/// iOS-side counterpart to WatchApp/WatchAlerts/WatchConnectivityManager.
/// Receives alerts sent from the watch, saves them into risk history, and
/// triggers caregiver notification for high/emergency levels.
final class PhoneConnectivityManager: NSObject, WCSessionDelegate, UNUserNotificationCenterDelegate {

    static let shared = PhoneConnectivityManager()
    private let session = WCSession.default
    private let emergencyManager = EmergencyContactManager()

    func activate() {
        guard WCSession.isSupported() else { return }
        session.delegate = self
        session.activate()
        UNUserNotificationCenter.current().delegate = self
    }

    func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any] = [:]) {
        handle(userInfo)
    }
    func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        handle(message)
    }

    private func handle(_ payload: [String: Any]) {
        guard payload["type"] as? String == "asthma_alert",
              let rawLevel = payload["riskLevel"] as? Int,
              let level = RiskLevel(rawValue: rawLevel) else { return }

        let vitals = VitalsSnapshot(
            spo2: (payload["spo2"] as? Double).flatMap { $0 >= 0 ? $0 : nil },
            heartRate: (payload["heartRate"] as? Double).flatMap { $0 >= 0 ? $0 : nil },
            respiratoryRate: (payload["respRate"] as? Double).flatMap { $0 >= 0 ? $0 : nil })

        let result = RiskResult(
            riskLevel: level,
            symptomCheck: nil,
            vitals: vitals,
            environment: nil,
            contributingFactors: ["Detected from Apple Watch vitals"],
            message: AppCopy.message(for: level))

        PersistenceStore.shared.appendRiskResult(result)

        DispatchQueue.main.async {
            self.showLocalNotification(for: result)
            let contactsToNotify = self.emergencyManager.contactsToNotify(for: level)
            if !contactsToNotify.isEmpty {
                // Phase 2: route through FirebaseService.notifyCaregivers so
                // this works even if the phone is locked/backgrounded.
                FirebaseService.shared.notifyCaregivers(contacts: contactsToNotify, result: result, userID: "current-user")
            }
        }
    }

    private func showLocalNotification(for result: RiskResult) {
        let content = UNMutableNotificationContent()
        content.title = "AsthmaGuard AI — \(result.riskLevel.label) Risk"
        content.body = result.message
        content.sound = .default
        content.interruptionLevel = .timeSensitive
        UNUserNotificationCenter.current().add(UNNotificationRequest(
            identifier: UUID().uuidString, content: content, trigger: nil))
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {}
    func sessionDidBecomeInactive(_ session: WCSession) {}
    func sessionDidDeactivate(_ session: WCSession) { session.activate() }
}
