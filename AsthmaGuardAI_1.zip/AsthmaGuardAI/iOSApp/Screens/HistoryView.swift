import SwiftUI
import Charts

struct HistoryView: View {
    @State private var history: [RiskResult] = PersistenceStore.shared.loadRiskHistory().sorted { $0.timestamp < $1.timestamp }
    @State private var showingShareSheet = false
    @State private var pdfData: Data?

    var body: some View {
        NavigationView {
            List {
                if !history.isEmpty {
                    Section("Risk Level Trend") {
                        Chart(history) { result in
                            LineMark(
                                x: .value("Date", result.timestamp),
                                y: .value("Risk", result.riskLevel.rawValue)
                            )
                            PointMark(
                                x: .value("Date", result.timestamp),
                                y: .value("Risk", result.riskLevel.rawValue)
                            )
                        }
                        .frame(height: 180)
                    }
                }

                Section("Events") {
                    ForEach(history.reversed()) { result in
                        VStack(alignment: .leading) {
                            HStack {
                                Text(result.riskLevel.label).bold()
                                Spacer()
                                Text(result.timestamp, style: .date).font(.caption).foregroundColor(.secondary)
                            }
                            Text(result.message).font(.caption)
                        }
                    }
                }
            }
            .navigationTitle("History")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Export PDF") { exportReport() }
                }
            }
            .sheet(isPresented: $showingShareSheet) {
                if let pdfData {
                    ShareSheet(activityItems: [pdfData])
                }
            }
        }
    }

    private func exportReport() {
        let profile = PersistenceStore.shared.loadProfile()
        let inhalerLog = PersistenceStore.shared.loadInhalerLog()
        let medications = PersistenceStore.shared.loadMedications()
        let range = (history.first?.timestamp ?? Date())...(history.last?.timestamp ?? Date())
        pdfData = PDFReportGenerator.generateReport(
            profile: profile, riskHistory: history, inhalerLog: inhalerLog,
            medications: medications, dateRange: range)
        showingShareSheet = true
    }
}

/// Thin wrapper so we can present the system share sheet from SwiftUI.
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
