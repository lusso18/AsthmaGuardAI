import SwiftUI

struct WelcomeView: View {
    @ObservedObject var coordinator: AppCoordinator

    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            Image(systemName: "lungs.fill")
                .font(.system(size: 64))
                .foregroundColor(.blue)
            Text("AsthmaGuard AI")
                .font(.largeTitle.bold())
            Text("Personal asthma symptom monitoring for you and the people who care about you.")
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
                .padding(.horizontal, 32)

            Text(AppCopy.disclaimer)
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)

            Spacer()
            Button {
                coordinator.advance(to: .profile)
            } label: {
                Text("Get Started")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .padding(.horizontal, 32)
            .padding(.bottom, 40)
        }
    }
}
