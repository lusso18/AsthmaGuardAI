/**
 * AsthmaGuard AI — Cloud Functions
 *
 * Deploy with: firebase deploy --only functions
 *
 * Data model this expects in Firestore:
 *
 * users/{userId}
 *   - name, asthmaSeverity, etc. (mirrors UserProfile)
 *   riskHistory/{resultId}
 *     - riskLevel: number (0=low,1=moderate,2=high,3=emergency)
 *     - message: string
 *     - timestamp: Firestore Timestamp
 *     - contributingFactors: string[]
 *   caregivers/{caregiverId}
 *     - name, relationship, phoneNumber
 *     - notifyOnHighRisk: boolean
 *     - notifyOnEmergency: boolean
 *     - fcmToken: string          (set once the caregiver's own device
 *                                  registers via registerCaregiverToken)
 *
 * Why a Firestore trigger and not a direct call from the phone: if the
 * patient's phone loses network, is locked, or the app is killed right after
 * a high-risk event, a client-initiated call may never complete. Writing the
 * risk result to Firestore (which can happen from a background task or even
 * be retried) and reacting server-side is much more reliable for something
 * safety-critical.
 */

const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();
const db = getFirestore();
const messaging = getMessaging();

const RISK_LEVEL_LABELS = ["Low", "Moderate", "High", "Emergency"];

/**
 * Fires whenever a new risk result is written for a user. If it's High or
 * Emergency, looks up that user's caregivers and pushes a notification to
 * whichever of them opted in for that level.
 */
exports.notifyCaregiversOnRiskEvent = onDocumentCreated(
  "users/{userId}/riskHistory/{resultId}",
  async (event) => {
    const result = event.data?.data();
    if (!result) return;

    const riskLevel = result.riskLevel ?? 0;
    if (riskLevel < 2) return; // only High (2) and Emergency (3) page caregivers

    const userId = event.params.userId;
    const userDoc = await db.collection("users").doc(userId).get();
    const userName = userDoc.exists ? (userDoc.data().name || "Your family member") : "Your family member";

    const caregiversSnap = await db
      .collection("users").doc(userId)
      .collection("caregivers")
      .get();

    const messages = [];
    caregiversSnap.forEach((doc) => {
      const caregiver = doc.data();
      if (!caregiver.fcmToken) return;

      const shouldNotify =
        (riskLevel === 2 && caregiver.notifyOnHighRisk) ||
        (riskLevel === 3 && (caregiver.notifyOnHighRisk || caregiver.notifyOnEmergency));
      if (!shouldNotify) return;

      messages.push({
        token: caregiver.fcmToken,
        notification: {
          title: `${userName} — ${RISK_LEVEL_LABELS[riskLevel]} risk alert`,
          body: result.message || "Possible asthma symptoms detected via AsthmaGuard AI.",
        },
        data: {
          userId,
          resultId: event.params.resultId,
          riskLevel: String(riskLevel),
        },
        apns: {
          payload: {
            aps: {
              // Emergency-level pushes request the highest visible priority;
              // truly bypassing Focus/Silent still requires Apple's Critical
              // Alerts entitlement and a critical-sound payload.
              sound: riskLevel === 3 ? "default" : "default",
              "interruption-level": riskLevel === 3 ? "critical" : "time-sensitive",
            },
          },
        },
      });
    });

    if (messages.length === 0) return;

    const response = await messaging.sendEach(messages);
    console.log(`Sent ${response.successCount}/${messages.length} caregiver alerts for user ${userId}`);
  }
);

/**
 * Callable function the CAREGIVER'S device invokes once, after accepting an
 * invite, to register its FCM token against the patient's caregiver record.
 * Keeping this separate from the patient's own token registration means a
 * patient's phone never needs to know a caregiver's token directly.
 */
exports.registerCaregiverToken = onCall(async (request) => {
  const { userId, caregiverId, fcmToken } = request.data;
  if (!userId || !caregiverId || !fcmToken) {
    throw new HttpsError("invalid-argument", "userId, caregiverId, and fcmToken are all required.");
  }

  await db
    .collection("users").doc(userId)
    .collection("caregivers").doc(caregiverId)
    .set({ fcmToken }, { merge: true });

  return { success: true };
});
