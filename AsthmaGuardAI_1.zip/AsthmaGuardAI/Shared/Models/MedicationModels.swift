import Foundation

enum MedicationType: String, Codable, CaseIterable, Identifiable {
    case rescueInhaler = "Rescue Inhaler"
    case controllerInhaler = "Controller Inhaler"
    case oral = "Oral Medication"
    case other = "Other"

    var id: String { rawValue }
}

struct Medication: Codable, Identifiable, Equatable {
    var id: UUID = UUID()
    var name: String
    var type: MedicationType
    var dosage: String
    var reminderTimes: [DateComponents] = []   // times of day for controller reminders
    var isActive: Bool = true
}

/// One entry every time the user logs using their rescue inhaler (or any med).
struct InhalerLogEntry: Codable, Identifiable, Equatable {
    var id: UUID = UUID()
    var medicationID: UUID
    var timestamp: Date = Date()
    var puffsTaken: Int = 1
    var triggeredByAppAlert: Bool = false      // true if logged from an app warning
    var associatedRiskLevel: String? = nil     // snapshot of risk level at time of use
    var notes: String = ""
}
