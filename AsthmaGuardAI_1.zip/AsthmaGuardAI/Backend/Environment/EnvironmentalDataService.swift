import Foundation
import CoreLocation

/// Placeholder service for Phase 3. Swap the mock implementation for real
/// calls to a weather API (e.g. WeatherKit/OpenWeather), a pollen API
/// (e.g. Ambee, Breezometer), and an air quality API (e.g. AirNow, IQAir).
final class EnvironmentalDataService {

    func fetchCurrentContext(location: CLLocation? = nil, completion: @escaping (EnvironmentalContext) -> Void) {
        // TODO Phase 3: replace with real network calls, something like:
        //   URLSession.shared.dataTask(with: weatherAPIRequest) { ... }
        //   URLSession.shared.dataTask(with: pollenAPIRequest) { ... }
        //   URLSession.shared.dataTask(with: airQualityAPIRequest) { ... }
        // and combine results before calling `completion`.

        let mock = EnvironmentalContext(
            pollenIndex: nil,
            airQualityIndex: nil,
            temperatureF: nil,
            isColdAirTrigger: false
        )
        completion(mock)
    }
}
