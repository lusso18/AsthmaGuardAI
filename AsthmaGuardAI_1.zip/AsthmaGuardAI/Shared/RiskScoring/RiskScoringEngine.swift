import Foundation

/// Combines subjective symptoms, HealthKit vitals, and environmental context
/// into one RiskResult. Used by both the manual "Check My Breathing" flow and
/// the background auto-monitoring flow (Phase 2).
///
/// Thresholds here are conservative starting points, not medical guidance —
/// they should be reviewed with a clinician and, ideally, adapted per-user
/// via `UserProfile.restingHeartRateBaseline` / `baselineRespiratoryRate`.
final class RiskScoringEngine {

    func evaluate(symptoms: SymptomCheck?,
                  vitals: VitalsSnapshot?,
                  environment: EnvironmentalContext?,
                  profile: UserProfile) -> RiskResult {

        var score = 0
        var reasons: [String] = []

        // --- Symptom questionnaire ---
        if let symptoms = symptoms {
            if symptoms.lipsOrFingersBluish {
                score += 6
                reasons.append("Bluish lips/fingers reported")
            }
            if symptoms.difficultySpeaking {
                score += 3
                reasons.append("Difficulty speaking full sentences reported")
            }
            let subjective = symptoms.shortnessOfBreath + symptoms.coughing + symptoms.wheezing + symptoms.chestTightness
            if subjective >= 6 {
                score += 3
                reasons.append("Multiple significant symptoms reported")
            } else if subjective >= 3 {
                score += 1
                reasons.append("Some symptoms reported")
            }
        }

        // --- Vitals ---
        if let spo2 = vitals?.spo2 {
            if spo2 < AppConstants.defaultSpo2AlertThreshold {
                score += 3
                reasons.append("SpO2 below \(Int(AppConstants.defaultSpo2AlertThreshold * 100))%")
            } else if spo2 < AppConstants.defaultSpo2WatchThreshold {
                score += 1
                reasons.append("SpO2 slightly low")
            }
        }

        if let respRate = vitals?.respiratoryRate {
            let baseline = profile.baselineRespiratoryRate ?? 16
            if respRate > baseline * 1.5 {
                score += 2
                reasons.append("Respiratory rate well above your baseline")
            } else if respRate > baseline * 1.25 {
                score += 1
                reasons.append("Respiratory rate above your baseline")
            }
        }

        if let hr = vitals?.heartRate {
            let restingBaseline = profile.restingHeartRateBaseline ?? vitals?.restingHeartRate ?? 70
            if hr > restingBaseline * 1.4 {
                score += 1
                reasons.append("Heart rate elevated above baseline")
            }
        }

        if let hrv = vitals?.heartRateVariability, hrv < 20 {
            score += 1
            reasons.append("Low heart rate variability")
        }

        // --- Environment ---
        if let aqi = environment?.airQualityIndex, aqi > 150 {
            score += 1
            reasons.append("Poor air quality today")
        }
        if let pollen = environment?.pollenIndex, pollen > 7, profile.knownTriggers.contains("pollen") {
            score += 1
            reasons.append("High pollen matches a known trigger")
        }
        if environment?.isColdAirTrigger == true, profile.knownTriggers.contains("cold air") {
            score += 1
            reasons.append("Cold air matches a known trigger")
        }

        let level: RiskLevel
        switch score {
        case 0...1: level = .low
        case 2...4: level = .moderate
        case 5...7: level = .high
        default: level = .emergency
        }

        return RiskResult(
            riskLevel: level,
            symptomCheck: symptoms,
            vitals: vitals,
            environment: environment,
            contributingFactors: reasons,
            message: AppCopy.message(for: level)
        )
    }
}
