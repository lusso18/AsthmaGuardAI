import Foundation

/// Phase 3 AI assistant: explains symptoms and helps the user follow their
/// own asthma action plan. Must never diagnose or claim certainty — see
/// `AppCopy.aiAssistantDisclaimer`.
///
/// SECURITY NOTE: never embed your OpenAI API key in the client app. Route
/// requests through your own backend (Firebase Cloud Function / Supabase Edge
/// Function) that holds the key server-side, and call that endpoint from here.
final class AIAssistantService {

    struct ChatMessage: Codable {
        let role: String   // "system" | "user" | "assistant"
        let content: String
    }

    private let backendEndpoint: URL   // your own server, NOT api.openai.com directly

    init(backendEndpoint: URL) {
        self.backendEndpoint = backendEndpoint
    }

    func ask(_ userMessage: String,
             profile: UserProfile,
             recentResult: RiskResult?,
             completion: @escaping (Result<String, Error>) -> Void) {

        let systemPrompt = """
        You are a supportive asthma-education assistant inside AsthmaGuard AI.
        You help the user understand possible symptoms and their own asthma
        action plan. You do NOT diagnose asthma attacks and you always
        encourage contacting a doctor or emergency services for anything
        serious or uncertain. Known triggers: \(profile.knownTriggers.joined(separator: ", ")).
        Action plan notes: \(profile.actionPlanNotes)
        """

        var messages = [ChatMessage(role: "system", content: systemPrompt)]
        if let result = recentResult {
            messages.append(ChatMessage(role: "system",
                content: "Most recent check: \(result.riskLevel.label) risk — \(result.message)"))
        }
        messages.append(ChatMessage(role: "user", content: userMessage))

        var request = URLRequest(url: backendEndpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(messages)

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let data = data,
                  let reply = try? JSONDecoder().decode(String.self, from: data) else {
                completion(.failure(NSError(domain: "AIAssistantService", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: "Could not parse assistant response"])))
                return
            }
            completion(.success(reply))
        }.resume()
    }
}
