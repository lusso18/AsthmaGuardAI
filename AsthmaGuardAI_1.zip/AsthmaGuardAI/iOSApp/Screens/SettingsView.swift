import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var profile = PersistenceStore.shared.loadProfile()
    @State private var isLearning = false
    @State private var learningStatus: String?

    private let baselineEngine = BaselineLearningEngine()

    var body: some View {
        NavigationView {
            Form {
                Section("Profile") {
                    TextField("Name", text: $profile.name)
                    Picker("Severity", selection: $profile.asthmaSeverity) {
                        ForEach(AsthmaSeverity.allCases) { s in Text(s.rawValue).tag(s) }
                    }
                }

                Section("Personal Baselines") {
                    HStack {
                        Text("Resting heart rate")
                        Spacer()
                        TextField("bpm", value: $profile.restingHeartRateBaseline, format: .number)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                    }
                    HStack {
                        Text("Baseline respiratory rate")
                        Spacer()
                        TextField("breaths/min", value: $profile.baselineRespiratoryRate, format: .number)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                    }

                    Button {
                        learnBaselinesNow()
                    } label: {
                        if isLearning {
                            ProgressView()
                        } else {
                            Label("Auto-Calibrate from Health Data", systemImage: "wand.and.stars")
                        }
                    }
                    .disabled(isLearning)

                    if let status = learningStatus {
                        Text(status).font(.caption).foregroundColor(.secondary)
                    }

                    Text("Auto-calibrate uses the last 3 weeks of your Health data (resting heart rate, and respiratory rate during sleep) to set these automatically. It only overwrites a value when there's enough data to trust — otherwise it leaves your manual entry alone.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }

                Section("About") {
                    Text(AppCopy.disclaimer)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }

                Button("Save") {
                    profile.lastUpdated = Date()
                    PersistenceStore.shared.saveProfile(profile)
                    dismiss()
                }
            }
            .navigationTitle("Settings")
        }
    }

    private func learnBaselinesNow() {
        isLearning = true
        learningStatus = nil
        baselineEngine.learnAndApplyToProfile { result in
            isLearning = false
            profile = PersistenceStore.shared.loadProfile() // reload with any applied changes

            var parts: [String] = []
            if let hr = result.restingHeartRate {
                parts.append("resting HR ≈ \(Int(hr)) bpm (\(result.sampleSizeRestingHR) samples)")
            }
            if let resp = result.respiratoryRate {
                parts.append("resp. rate ≈ \(Int(resp))/min (\(result.sampleSizeRespRate) samples)")
            }
            learningStatus = parts.isEmpty
                ? "Not enough recent Health data yet to calibrate."
                : "Learned: " + parts.joined(separator: ", ")
        }
    }
}
