import SwiftUI
import MessageUI

struct RiskResultView: View {
    let result: RiskResult
    @Environment(\.dismiss) private var dismiss
    @StateObject private var medicationStore = MedicationStore()
    @StateObject private var emergencyManager = EmergencyContactManager()
    @State private var showingMessageComposer = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    Text(result.riskLevel.label)
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(color(for: result.riskLevel))

                    Text(result.message)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)

                    if !result.contributingFactors.isEmpty {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Contributing factors").font(.headline)
                            ForEach(result.contributingFactors, id: \.self) { factor in
                                Text("• \(factor)").font(.footnote).foregroundColor(.secondary)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(12)
                        .padding(.horizontal)
                    }

                    if result.riskLevel >= .high {
                        actionButtons
                    }

                    Text(AppCopy.disclaimer)
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .navigationTitle("Result")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private var actionButtons: some View {
        VStack(spacing: 12) {
            if let rescueInhaler = medicationStore.medications.first(where: { $0.type == .rescueInhaler }) {
                Button {
                    medicationStore.logInhalerUse(medication: rescueInhaler, fromAlert: true, riskLevel: result.riskLevel)
                } label: {
                    Label("I used my rescue inhaler", systemImage: "checkmark.circle.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
            }

            if !emergencyManager.contactsToNotify(for: result.riskLevel).isEmpty {
                Button {
                    showingMessageComposer = true
                } label: {
                    Label("Alert my emergency contact", systemImage: "person.fill.checkmark")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }

            if result.riskLevel == .emergency, let url = emergencyManager.emergencyCallURL() {
                Link(destination: url) {
                    Label("Call 911", systemImage: "phone.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
            }
        }
        .padding(.horizontal)
    }

    private func color(for level: RiskLevel) -> Color {
        switch level {
        case .low: return .green
        case .moderate: return .yellow
        case .high: return .orange
        case .emergency: return .red
        }
    }
}
