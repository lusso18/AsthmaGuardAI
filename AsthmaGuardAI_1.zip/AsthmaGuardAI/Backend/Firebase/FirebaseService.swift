import Foundation
// import FirebaseAuth
// import FirebaseFirestore

/// Backend sync. Add the Firebase SDK via Swift Package Manager
/// (FirebaseAuth, FirebaseFirestore, FirebaseMessaging), uncomment the
/// imports above, and uncomment the Firestore calls below. Once
/// `syncRiskResult` writes to `users/{userId}/riskHistory/{resultId}`, the
/// `notifyCaregiversOnRiskEvent` Cloud Function (see
/// Backend/Firebase/functions/index.js) fires automatically for High/
/// Emergency events — no separate "notify" call needed from the client for
/// that to work, which is what makes it reliable even if the phone loses
/// connectivity right after.
final class FirebaseService {

    static let shared = FirebaseService()

    // MARK: - Auth (stub)
    func signIn(email: String, password: String, completion: @escaping (Result<Void, Error>) -> Void) {
        // TODO: Auth.auth().signIn(withEmail:password:completion:)
        completion(.success(()))
    }

    func signUp(email: String, password: String, completion: @escaping (Result<Void, Error>) -> Void) {
        // TODO: Auth.auth().createUser(withEmail:password:completion:)
        completion(.success(()))
    }

    // MARK: - Firestore sync
    /// Writing this document is what triggers `notifyCaregiversOnRiskEvent`
    /// server-side for High/Emergency risk levels — the actual caregiver
    /// paging logic lives in the Cloud Function, not here.
    func syncRiskResult(_ result: RiskResult, userID: String) {
        // TODO:
        // let db = Firestore.firestore()
        // try? db.collection("users").document(userID)
        //   .collection("riskHistory").document(result.id.uuidString)
        //   .setData(from: result)
    }

    func syncInhalerLogEntry(_ entry: InhalerLogEntry, userID: String) {
        // TODO:
        // let db = Firestore.firestore()
        // try? db.collection("users").document(userID)
        //   .collection("inhalerLog").document(entry.id.uuidString)
        //   .setData(from: entry)
    }

    // MARK: - Caregiver notifications
    /// Kept as a no-op client-side entry point for backward compatibility —
    /// the real fan-out now happens in the Cloud Function triggered by
    /// `syncRiskResult`. If you want an immediate client-triggered nudge in
    /// addition (e.g. for testing), you can call an `onCall` function here
    /// instead of relying purely on the Firestore trigger.
    func notifyCaregivers(contacts: [EmergencyContact], result: RiskResult, userID: String) {
        syncRiskResult(result, userID: userID)
    }
}
