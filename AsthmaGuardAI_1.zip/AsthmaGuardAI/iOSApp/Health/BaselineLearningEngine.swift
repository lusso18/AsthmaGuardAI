import HealthKit
import Foundation

/// Learns a person's real resting heart rate and typical (awake, calm)
/// respiratory rate from their own HealthKit history, instead of relying on
/// the generic 70bpm / 16 breaths-per-minute defaults or manual entry.
///
/// Approach, kept intentionally simple and explainable rather than a black
/// box, since this feeds a safety-relevant threshold:
///  - Resting heart rate: HealthKit already computes a daily
///    `restingHeartRate` sample. We take the median of the last N days.
///  - Respiratory rate baseline: HealthKit's `respiratoryRate` samples are
///    almost all captured during sleep, which is exactly the "calm"
///    condition we want for a baseline. We take the median of respiratory
///    rate samples restricted to time windows that overlap sleep-analysis
///    "asleep" categories over the last N days.
///
/// Median (not mean) is used deliberately — it's far less sensitive to a
/// handful of outlier readings (e.g. a stressful night, a sensor glitch),
/// which matters because these baselines directly change when the app
/// decides to alarm.
final class BaselineLearningEngine {

    private let store = HKHealthStore()
    private let lookbackDays: Int

    init(lookbackDays: Int = 21) {
        self.lookbackDays = lookbackDays
    }

    struct LearnedBaselines {
        let restingHeartRate: Double?
        let respiratoryRate: Double?
        let sampleSizeRestingHR: Int
        let sampleSizeRespRate: Int
    }

    func learnBaselines(completion: @escaping (LearnedBaselines) -> Void) {
        let group = DispatchGroup()
        var restingHRMedian: Double?
        var restingHRCount = 0
        var respRateMedian: Double?
        var respRateCount = 0

        group.enter()
        fetchRestingHeartRateMedian { median, count in
            restingHRMedian = median
            restingHRCount = count
            group.leave()
        }

        group.enter()
        fetchSleepRespiratoryRateMedian { median, count in
            respRateMedian = median
            respRateCount = count
            group.leave()
        }

        group.notify(queue: .main) {
            completion(LearnedBaselines(
                restingHeartRate: restingHRMedian,
                respiratoryRate: respRateMedian,
                sampleSizeRestingHR: restingHRCount,
                sampleSizeRespRate: respRateCount))
        }
    }

    /// Applies learned baselines to the stored profile, but only when there's
    /// enough data to trust — a baseline computed from 1-2 samples could be
    /// noise, and silently overwriting a manually-entered value with noise is
    /// worse than leaving it alone.
    func learnAndApplyToProfile(minimumSamples: Int = 5, completion: ((LearnedBaselines) -> Void)? = nil) {
        learnBaselines { result in
            var profile = PersistenceStore.shared.loadProfile()
            var changed = false

            if let hr = result.restingHeartRate, result.sampleSizeRestingHR >= minimumSamples {
                profile.restingHeartRateBaseline = hr
                changed = true
            }
            if let resp = result.respiratoryRate, result.sampleSizeRespRate >= minimumSamples {
                profile.baselineRespiratoryRate = resp
                changed = true
            }
            if changed {
                profile.lastUpdated = Date()
                PersistenceStore.shared.saveProfile(profile)
            }
            completion?(result)
        }
    }

    // MARK: - Resting heart rate

    private func fetchRestingHeartRateMedian(completion: @escaping (Double?, Int) -> Void) {
        guard let type = HKQuantityType.quantityType(forIdentifier: .restingHeartRate) else {
            completion(nil, 0); return
        }
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: Date(), options: .strictStartDate)
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: true)
        let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: [sort]) { _, samples, _ in
            let values = (samples as? [HKQuantitySample])?.map {
                $0.quantity.doubleValue(for: HKUnit.count().unitDivided(by: .minute()))
            } ?? []
            completion(median(of: values), values.count)
        }
        store.execute(query)
    }

    // MARK: - Respiratory rate during sleep

    private func fetchSleepRespiratoryRateMedian(completion: @escaping (Double?, Int) -> Void) {
        guard let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis),
              let respType = HKQuantityType.quantityType(forIdentifier: .respiratoryRate) else {
            completion(nil, 0); return
        }

        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: Date(), options: .strictStartDate)
        let sleepQuery = HKSampleQuery(sampleType: sleepType, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { [weak self] _, sleepSamples, _ in
            guard let self else { completion(nil, 0); return }

            let asleepIntervals: [(Date, Date)] = (sleepSamples as? [HKCategorySample])?
                .filter { self.isAsleepValue($0.value) }
                .map { ($0.startDate, $0.endDate) } ?? []

            guard !asleepIntervals.isEmpty else { completion(nil, 0); return }

            let respPredicate = HKQuery.predicateForSamples(withStart: self.startDate, end: Date(), options: .strictStartDate)
            let respQuery = HKSampleQuery(sampleType: respType, predicate: respPredicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, respSamples, _ in
                let unit = HKUnit.count().unitDivided(by: .minute())
                let valuesDuringSleep = (respSamples as? [HKQuantitySample])?.compactMap { sample -> Double? in
                    let overlaps = asleepIntervals.contains { interval in
                        sample.startDate < interval.1 && sample.endDate > interval.0
                    }
                    return overlaps ? sample.quantity.doubleValue(for: unit) : nil
                } ?? []
                completion(median(of: valuesDuringSleep), valuesDuringSleep.count)
            }
            self.store.execute(respQuery)
        }
        store.execute(sleepQuery)
    }

    private func isAsleepValue(_ value: Int) -> Bool {
        // HKCategoryValueSleepAnalysis: asleepCore/Deep/REM/Unspecified all count as asleep.
        if #available(iOS 16.0, watchOS 9.0, *) {
            return value == HKCategoryValueSleepAnalysis.asleepCore.rawValue
                || value == HKCategoryValueSleepAnalysis.asleepDeep.rawValue
                || value == HKCategoryValueSleepAnalysis.asleepREM.rawValue
                || value == HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue
        } else {
            return value == HKCategoryValueSleepAnalysis.asleep.rawValue
        }
    }

    private var startDate: Date {
        Calendar.current.date(byAdding: .day, value: -lookbackDays, to: Date()) ?? Date()
    }
}

private func median(of values: [Double]) -> Double? {
    guard !values.isEmpty else { return nil }
    let sorted = values.sorted()
    let mid = sorted.count / 2
    return sorted.count % 2 == 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid]
}
