import Foundation

/// Core user-entered asthma profile — collected during onboarding, editable in Settings.
struct UserProfile: Codable, Equatable {
    var name: String = ""
    var dateOfBirth: Date? = nil
    var asthmaSeverity: AsthmaSeverity = .unspecified
    var knownTriggers: [String] = []          // e.g. "pollen", "cold air", "exercise"
    var actionPlanNotes: String = ""          // free text from their doctor's asthma action plan
    var restingHeartRateBaseline: Double? = nil
    var baselineRespiratoryRate: Double? = nil
    var lastUpdated: Date = Date()
}

enum AsthmaSeverity: String, Codable, CaseIterable, Identifiable {
    case unspecified = "Not specified"
    case intermittent = "Intermittent"
    case mildPersistent = "Mild Persistent"
    case moderatePersistent = "Moderate Persistent"
    case severePersistent = "Severe Persistent"

    var id: String { rawValue }
}
