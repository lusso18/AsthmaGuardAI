import SwiftUI

struct EmergencyContactSetupView: View {
    @ObservedObject var coordinator: AppCoordinator
    @StateObject private var manager = EmergencyContactManager()
    @State private var name = ""
    @State private var relationship = ""
    @State private var phone = ""

    var body: some View {
        Form {
            Section("Add Emergency Contact") {
                TextField("Name", text: $name)
                TextField("Relationship (e.g. Parent)", text: $relationship)
                TextField("Phone number", text: $phone)
                    .keyboardType(.phonePad)
                Button("Add Contact") {
                    guard !name.isEmpty, !phone.isEmpty else { return }
                    manager.addContact(EmergencyContact(name: name, relationship: relationship, phoneNumber: phone))
                    name = ""; relationship = ""; phone = ""
                }
            }

            Section("Your Contacts") {
                ForEach(manager.contacts) { contact in
                    VStack(alignment: .leading) {
                        Text(contact.name).bold()
                        Text("\(contact.relationship) • \(contact.phoneNumber)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                .onDelete { indexSet in
                    indexSet.map { manager.contacts[$0] }.forEach(manager.removeContact)
                }
            }

            Section {
                Button("Enable Location Sharing on Alerts") {
                    manager.requestLocationPermission()
                }
            }

            Button(manager.contacts.isEmpty ? "Skip for now" : "Continue") {
                coordinator.advance(to: .medication)
            }
        }
        .navigationTitle("Emergency Contacts")
    }
}
