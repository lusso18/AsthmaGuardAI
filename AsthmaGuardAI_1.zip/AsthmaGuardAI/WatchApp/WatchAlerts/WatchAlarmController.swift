import WatchKit
import UserNotifications

/// Fires an escalating on-watch alarm and mirrors the alert to the phone.
/// Wording stays non-diagnostic ("possible symptoms") per AppCopy.
final class WatchAlarmController: NSObject, ObservableObject {

    @Published var isAlarming = false
    private var escalationTimer: Timer?
    private var escalationStep = 0

    func startAlarm(riskLevel: RiskLevel) {
        guard !isAlarming else { return }
        isAlarming = true
        escalationStep = 0
        fireHaptic()
        postNotification(riskLevel: riskLevel)

        escalationTimer = Timer.scheduledTimer(withTimeInterval: AppConstants.escalationWindowSeconds, repeats: true) { [weak self] _ in
            self?.escalate(riskLevel: riskLevel)
        }
    }

    func acknowledge() {
        isAlarming = false
        escalationTimer?.invalidate()
        escalationTimer = nil
    }

    private func escalate(riskLevel: RiskLevel) {
        escalationStep += 1
        fireHaptic()
        if escalationStep >= 2 {
            NotificationCenter.default.post(name: .asthmaAlarmEscalated, object: riskLevel)
        }
    }

    private func fireHaptic() {
        WKInterfaceDevice.current().play(.notification)
    }

    private func postNotification(riskLevel: RiskLevel) {
        let content = UNMutableNotificationContent()
        content.title = "AsthmaGuard AI"
        content.body = AppCopy.message(for: riskLevel)
        content.sound = .default
        content.interruptionLevel = .timeSensitive

        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
    }
}

extension Notification.Name {
    static let asthmaAlarmEscalated = Notification.Name("asthmaAlarmEscalated")
}
