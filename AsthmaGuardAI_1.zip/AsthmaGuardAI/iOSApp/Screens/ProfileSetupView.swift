import SwiftUI

struct ProfileSetupView: View {
    @ObservedObject var coordinator: AppCoordinator
    @State private var profile = PersistenceStore.shared.loadProfile()
    @State private var newTrigger = ""

    private let commonTriggers = ["pollen", "cold air", "exercise", "dust", "smoke", "pet dander", "stress"]

    var body: some View {
        Form {
            Section("About You") {
                TextField("Name", text: $profile.name)
                DatePicker("Date of birth", selection: Binding(
                    get: { profile.dateOfBirth ?? Date() },
                    set: { profile.dateOfBirth = $0 }), displayedComponents: .date)
            }

            Section("Asthma Severity") {
                Picker("Severity", selection: $profile.asthmaSeverity) {
                    ForEach(AsthmaSeverity.allCases) { severity in
                        Text(severity.rawValue).tag(severity)
                    }
                }
            }

            Section("Known Triggers") {
                ForEach(commonTriggers, id: \.self) { trigger in
                    Toggle(trigger.capitalized, isOn: Binding(
                        get: { profile.knownTriggers.contains(trigger) },
                        set: { isOn in
                            if isOn { profile.knownTriggers.append(trigger) }
                            else { profile.knownTriggers.removeAll { $0 == trigger } }
                        }))
                }
                HStack {
                    TextField("Add custom trigger", text: $newTrigger)
                    Button("Add") {
                        guard !newTrigger.isEmpty else { return }
                        profile.knownTriggers.append(newTrigger)
                        newTrigger = ""
                    }
                }
            }

            Section("Asthma Action Plan Notes") {
                TextEditor(text: $profile.actionPlanNotes)
                    .frame(minHeight: 100)
                Text("Optional: copy key points from your doctor's written action plan.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Button("Continue") {
                profile.lastUpdated = Date()
                PersistenceStore.shared.saveProfile(profile)
                coordinator.advance(to: .emergencyContacts)
            }
        }
        .navigationTitle("Your Profile")
    }
}
