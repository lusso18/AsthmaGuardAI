import HealthKit
import Combine

/// watchOS-side HealthKit reader. Runs in its own process from the iOS app,
/// so it needs its own HKHealthStore + authorization request, and syncs
/// results to the phone via WatchConnectivityManager.
final class WatchHealthKitManager: ObservableObject {

    static let shared = WatchHealthKitManager()
    private let store = HKHealthStore()

    @Published var latestSpO2: Double?
    @Published var latestRespiratoryRate: Double?
    @Published var latestHeartRate: Double?

    private let spo2Type = HKQuantityType.quantityType(forIdentifier: .oxygenSaturation)!
    private let respType = HKQuantityType.quantityType(forIdentifier: .respiratoryRate)!
    private let hrType = HKQuantityType.quantityType(forIdentifier: .heartRate)!

    func requestAuthorization(completion: @escaping (Bool) -> Void) {
        guard HKHealthStore.isHealthDataAvailable() else { completion(false); return }
        let readTypes: Set<HKObjectType> = [spo2Type, respType, hrType]
        store.requestAuthorization(toShare: [], read: readTypes) { [weak self] success, _ in
            DispatchQueue.main.async { completion(success) }
            if success { self?.startObserving() }
        }
    }

    private func startObserving() {
        observe(spo2Type, unit: .percent()) { [weak self] in self?.latestSpO2 = $0 }
        observe(respType, unit: HKUnit.count().unitDivided(by: .minute())) { [weak self] in self?.latestRespiratoryRate = $0 }
        observe(hrType, unit: HKUnit.count().unitDivided(by: .minute())) { [weak self] in self?.latestHeartRate = $0 }
    }

    private func observe(_ type: HKQuantityType, unit: HKUnit, onValue: @escaping (Double) -> Void) {
        let observer = HKObserverQuery(sampleType: type, predicate: nil) { [weak self] _, completionHandler, _ in
            defer { completionHandler() }
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
            let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1, sortDescriptors: [sort]) { _, samples, _ in
                guard let sample = samples?.first as? HKQuantitySample else { return }
                DispatchQueue.main.async { onValue(sample.quantity.doubleValue(for: unit)) }
            }
            self?.store.execute(query)
        }
        store.execute(observer)
        store.enableBackgroundDelivery(for: type, frequency: .immediate) { _, _ in }
    }
}
