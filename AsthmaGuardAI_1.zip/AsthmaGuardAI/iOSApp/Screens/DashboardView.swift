import SwiftUI

struct DashboardView: View {
    @StateObject private var health = HealthKitManager.shared
    @StateObject private var medicationStore = MedicationStore()
    @State private var showingCheckFlow = false
    @State private var showingHistory = false
    @State private var showingSettings = false
    @State private var showingInhalerLog = false

    private var missedDoses: [Medication] { medicationStore.missedDoseMedications() }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    if !missedDoses.isEmpty {
                        missedDoseBanner
                    }

                    vitalsCard

                    Button {
                        showingCheckFlow = true
                    } label: {
                        VStack(spacing: 6) {
                            Image(systemName: "waveform.path.ecg")
                                .font(.system(size: 28))
                            Text("Check My Breathing")
                                .font(.headline)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.blue)

                    HStack(spacing: 12) {
                        quickButton("Inhaler Log", icon: "lungs") { showingInhalerLog = true }
                        quickButton("History", icon: "clock.arrow.circlepath") { showingHistory = true }
                    }
                }
                .padding()
            }
            .navigationTitle("AsthmaGuard AI")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showingSettings = true } label: { Image(systemName: "gearshape") }
                }
            }
            .sheet(isPresented: $showingCheckFlow) { CheckMyBreathingView() }
            .sheet(isPresented: $showingHistory) { HistoryView() }
            .sheet(isPresented: $showingSettings) { SettingsView() }
            .sheet(isPresented: $showingInhalerLog) { InhalerLogView(store: medicationStore) }
        }
    }

    private var missedDoseBanner: some View {
        HStack {
            Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.orange)
            Text("You have \(missedDoses.count) missed controller dose(s) today.")
                .font(.footnote)
            Spacer()
        }
        .padding()
        .background(Color.orange.opacity(0.15))
        .cornerRadius(10)
    }

    private var vitalsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Latest Vitals").font(.headline)
            HStack {
                vitalStat("SpO2", health.latestSpO2.map { "\(Int($0 * 100))%" } ?? "—")
                vitalStat("Resp.", health.latestRespiratoryRate.map { "\(Int($0))/min" } ?? "—")
                vitalStat("HR", health.latestHeartRate.map { "\(Int($0)) bpm" } ?? "—")
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(12)
    }

    private func vitalStat(_ label: String, _ value: String) -> some View {
        VStack {
            Text(value).font(.title3.bold())
            Text(label).font(.caption).foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private func quickButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                Text(title).font(.caption)
            }
            .frame(maxWidth: .infinity)
            .padding()
        }
        .buttonStyle(.bordered)
    }
}
