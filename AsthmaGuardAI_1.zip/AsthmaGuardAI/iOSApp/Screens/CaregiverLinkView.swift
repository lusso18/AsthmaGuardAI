import SwiftUI
// import FirebaseMessaging
// import FirebaseFunctions

/// Meant to run on the CAREGIVER's own phone (a lightweight mode of the same
/// app, or a separate target) after they tap an invite link the patient
/// shares. Registers this device's FCM token against the patient's record so
/// the `notifyCaregiversOnRiskEvent` Cloud Function can reach them directly —
/// the patient's phone never sees or stores the caregiver's token.
struct CaregiverLinkView: View {
    let patientUserID: String
    let caregiverID: String

    @State private var status: String = ""
    @State private var isLinking = false

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "person.2.fill")
                .font(.system(size: 48))
                .foregroundColor(.blue)
            Text("Get Alerts")
                .font(.title2.bold())
            Text("You'll receive a notification if this person's AsthmaGuard AI detects a high-risk event.")
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
                .padding(.horizontal, 32)

            Button {
                linkDevice()
            } label: {
                if isLinking { ProgressView() }
                else { Text("Enable Alerts on This Device") }
            }
            .buttonStyle(.borderedProminent)
            .disabled(isLinking)

            if !status.isEmpty {
                Text(status).font(.footnote).foregroundColor(.secondary)
            }
        }
        .padding()
    }

    private func linkDevice() {
        isLinking = true
        // TODO once FirebaseMessaging is added:
        // Messaging.messaging().token { token, error in
        //     guard let token = token else { status = "Couldn't get device token."; isLinking = false; return }
        //     let functions = Functions.functions()
        //     functions.httpsCallable("registerCaregiverToken").call([
        //         "userId": patientUserID,
        //         "caregiverId": caregiverID,
        //         "fcmToken": token
        //     ]) { _, error in
        //         isLinking = false
        //         status = error == nil ? "You're all set — alerts are enabled." : "Something went wrong. Try again."
        //     }
        // }
        status = "Firebase Messaging not yet wired up — see TODO in this file."
        isLinking = false
    }
}
