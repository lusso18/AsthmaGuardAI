import SwiftUI

struct WatchDashboardView: View {
    @StateObject private var health = WatchHealthKitManager.shared
    @StateObject private var alarm = WatchAlarmController()
    @State private var riskLevel: RiskLevel = .low

    var body: some View {
        ScrollView {
            VStack(spacing: 10) {
                Text(riskLevel.label)
                    .font(.headline)
                    .foregroundColor(color(for: riskLevel))

                metricRow("SpO2", health.latestSpO2.map { "\(Int($0 * 100))%" } ?? "—")
                metricRow("Resp.", health.latestRespiratoryRate.map { "\(Int($0))/min" } ?? "—")
                metricRow("HR", health.latestHeartRate.map { "\(Int($0)) bpm" } ?? "—")

                if alarm.isAlarming {
                    Button("I'm OK") { alarm.acknowledge() }
                        .tint(.red)
                }

                Button("Check My Breathing") {
                    evaluateAndMaybeAlarm()
                }
                .tint(.blue)
            }
            .padding()
        }
        .onAppear {
            health.requestAuthorization { _ in }
            WatchConnectivityManager.shared.activate()
        }
    }

    /// Lightweight on-watch risk pass using vitals only (no symptom
    /// questionnaire — that lives on the phone). This is meant as a quick
    /// early signal, not a substitute for the full "Check My Breathing" flow.
    private func evaluateAndMaybeAlarm() {
        var score = 0
        if let spo2 = health.latestSpO2, spo2 < AppConstants.defaultSpo2AlertThreshold { score += 2 }
        if let hr = health.latestHeartRate, hr > 120 { score += 1 }

        riskLevel = score >= 2 ? .high : (score == 1 ? .moderate : .low)

        if riskLevel >= .high {
            alarm.startAlarm(riskLevel: riskLevel)
            WatchConnectivityManager.shared.sendAlert(
                riskLevel: riskLevel,
                spo2: health.latestSpO2,
                respRate: health.latestRespiratoryRate,
                heartRate: health.latestHeartRate)
        }
    }

    private func metricRow(_ label: String, _ value: String) -> some View {
        HStack {
            Text(label).foregroundColor(.secondary)
            Spacer()
            Text(value).bold()
        }
        .font(.caption)
    }

    private func color(for level: RiskLevel) -> Color {
        switch level {
        case .low: return .green
        case .moderate: return .yellow
        case .high: return .orange
        case .emergency: return .red
        }
    }
}
