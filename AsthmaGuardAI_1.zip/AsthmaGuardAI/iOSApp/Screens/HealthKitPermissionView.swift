import SwiftUI

struct HealthKitPermissionView: View {
    @ObservedObject var coordinator: AppCoordinator
    @StateObject private var health = HealthKitManager.shared
    @State private var requested = false

    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: "heart.text.square.fill")
                .font(.system(size: 56))
                .foregroundColor(.pink)
            Text("Connect Health Data")
                .font(.title2.bold())
            Text("AsthmaGuard AI reads your heart rate, respiratory rate, oxygen saturation, HRV, sleep, and step count from Apple Health to help estimate your risk level. This data stays on your device unless you choose to sync it.")
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
                .padding(.horizontal, 32)
            Spacer()

            Button {
                health.requestAuthorization { _ in
                    requested = true
                    coordinator.completeOnboarding()
                }
            } label: {
                Text("Allow Health Access")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .padding(.horizontal, 32)

            Button("Skip for now") {
                coordinator.completeOnboarding()
            }
            .padding(.bottom, 40)
        }
    }
}
