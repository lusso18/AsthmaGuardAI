import SwiftUI

struct CheckMyBreathingView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = BreathingCheckViewModel()
    @State private var showingResult = false

    var body: some View {
        NavigationView {
            Form {
                Section("How are you feeling right now?") {
                    symptomSlider("Shortness of breath", value: $viewModel.symptomCheck.shortnessOfBreath)
                    symptomSlider("Coughing", value: $viewModel.symptomCheck.coughing)
                    symptomSlider("Wheezing", value: $viewModel.symptomCheck.wheezing)
                    symptomSlider("Chest tightness", value: $viewModel.symptomCheck.chestTightness)
                    Toggle("Difficulty speaking full sentences", isOn: $viewModel.symptomCheck.difficultySpeaking)
                    Toggle("Bluish lips or fingertips", isOn: $viewModel.symptomCheck.lipsOrFingersBluish)
                }

                Section {
                    Button {
                        viewModel.runCheck { _ in showingResult = true }
                    } label: {
                        if viewModel.isChecking {
                            ProgressView()
                        } else {
                            Text("Check My Breathing").bold()
                        }
                    }
                    .disabled(viewModel.isChecking)
                }
            }
            .navigationTitle("Check My Breathing")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .sheet(isPresented: $showingResult) {
                if let result = viewModel.latestResult {
                    RiskResultView(result: result)
                }
            }
        }
    }

    private func symptomSlider(_ label: String, value: Binding<Int>) -> some View {
        VStack(alignment: .leading) {
            Text(label)
            Picker(label, selection: value) {
                Text("None").tag(0)
                Text("Mild").tag(1)
                Text("Moderate").tag(2)
                Text("Severe").tag(3)
            }
            .pickerStyle(.segmented)
            .labelsHidden()
        }
    }
}
