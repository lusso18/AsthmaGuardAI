import Foundation
import BackgroundTasks

/// Registers a weekly background task that re-runs baseline learning, so
/// thresholds keep adapting (e.g. as fitness/health changes) without the
/// person needing to remember to tap "Auto-Calibrate" in Settings.
///
/// Wire this up in your App's `init()` or AppDelegate:
///   BaselineRefreshScheduler.register()
/// and call `BaselineRefreshScheduler.scheduleNext()` after each successful run
/// (including the first time, e.g. right after onboarding completes).
///
/// Also add to Info.plist under `BGTaskSchedulerPermittedIdentifiers`:
///   com.asthmaguard.baselineRefresh
enum BaselineRefreshScheduler {
    static let taskIdentifier = "com.asthmaguard.baselineRefresh"
    private static let engine = BaselineLearningEngine()

    static func register() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: taskIdentifier, using: nil) { task in
            handle(task: task as! BGAppRefreshTask)
        }
    }

    static func scheduleNext() {
        let request = BGAppRefreshTaskRequest(identifier: taskIdentifier)
        request.earliestBeginDate = Calendar.current.date(byAdding: .day, value: 7, to: Date())
        try? BGTaskScheduler.shared.submit(request)
    }

    private static func handle(task: BGAppRefreshTask) {
        scheduleNext() // always schedule the next one before doing work

        let operation = BlockOperation {
            let semaphore = DispatchSemaphore(value: 0)
            engine.learnAndApplyToProfile { _ in semaphore.signal() }
            semaphore.wait()
        }

        task.expirationHandler = { operation.cancel() }
        operation.completionBlock = { task.setTaskCompleted(success: !operation.isCancelled) }

        OperationQueue().addOperation(operation)
    }
}
