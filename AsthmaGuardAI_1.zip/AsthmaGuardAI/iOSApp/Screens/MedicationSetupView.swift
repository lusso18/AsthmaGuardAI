import SwiftUI

struct MedicationSetupView: View {
    @ObservedObject var coordinator: AppCoordinator
    @StateObject private var store = MedicationStore()

    @State private var name = ""
    @State private var type: MedicationType = .rescueInhaler
    @State private var dosage = ""
    @State private var reminderTime = Date()
    @State private var addReminder = false

    var body: some View {
        Form {
            Section("Add Medication") {
                TextField("Name (e.g. Albuterol)", text: $name)
                Picker("Type", selection: $type) {
                    ForEach(MedicationType.allCases) { t in Text(t.rawValue).tag(t) }
                }
                TextField("Dosage (e.g. 2 puffs)", text: $dosage)

                if type == .controllerInhaler || type == .oral {
                    Toggle("Set a daily reminder", isOn: $addReminder)
                    if addReminder {
                        DatePicker("Reminder time", selection: $reminderTime, displayedComponents: .hourAndMinute)
                    }
                }

                Button("Add Medication") {
                    guard !name.isEmpty else { return }
                    var reminders: [DateComponents] = []
                    if addReminder {
                        reminders = [Calendar.current.dateComponents([.hour, .minute], from: reminderTime)]
                    }
                    store.addMedication(Medication(name: name, type: type, dosage: dosage, reminderTimes: reminders))
                    name = ""; dosage = ""; addReminder = false
                }
            }

            Section("Your Medications") {
                ForEach(store.medications) { med in
                    VStack(alignment: .leading) {
                        Text(med.name).bold()
                        Text("\(med.type.rawValue) • \(med.dosage)")
                            .font(.caption).foregroundColor(.secondary)
                    }
                }
                .onDelete { indexSet in
                    indexSet.map { store.medications[$0] }.forEach(store.removeMedication)
                }
            }

            Button(store.medications.isEmpty ? "Skip for now" : "Continue") {
                coordinator.advance(to: .healthKitPermission)
            }
        }
        .navigationTitle("Medications")
    }
}
