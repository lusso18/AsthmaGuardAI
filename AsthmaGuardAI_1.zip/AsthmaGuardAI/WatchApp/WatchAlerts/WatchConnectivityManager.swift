import WatchConnectivity

/// Watch-side messenger — sends risk alerts and vitals snapshots to the
/// paired iPhone, so the iPhone can log history, notify caregivers, and
/// escalate through Firebase Cloud Messaging if needed.
final class WatchConnectivityManager: NSObject, WCSessionDelegate {

    static let shared = WatchConnectivityManager()
    private let session = WCSession.default

    func activate() {
        guard WCSession.isSupported() else { return }
        session.delegate = self
        session.activate()
    }

    func sendAlert(riskLevel: RiskLevel, spo2: Double?, respRate: Double?, heartRate: Double?) {
        guard session.activationState == .activated else { return }
        let payload: [String: Any] = [
            "type": "asthma_alert",
            "riskLevel": riskLevel.rawValue,
            "spo2": spo2 ?? -1,
            "respRate": respRate ?? -1,
            "heartRate": heartRate ?? -1,
            "timestamp": Date().timeIntervalSince1970
        ]
        session.transferUserInfo(payload) // delivered even if phone app isn't foregrounded
        if session.isReachable {
            session.sendMessage(payload, replyHandler: nil, errorHandler: nil)
        }
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {}
}
