import Foundation

struct EmergencyContact: Codable, Identifiable, Equatable {
    var id: UUID = UUID()
    var name: String
    var relationship: String   // e.g. "Parent", "Spouse", "Friend"
    var phoneNumber: String
    var notifyOnHighRisk: Bool = true
    var notifyOnEmergency: Bool = true
    var shareLocationOnAlert: Bool = true
}
