import PDFKit
import UIKit

/// Generates a clinician-facing summary PDF: symptom/attack history,
/// inhaler use, vitals trends, and known triggers. Meant to be shared via the
/// system share sheet (email, AirDrop, Files) — not sent automatically.
enum PDFReportGenerator {

    static func generateReport(profile: UserProfile,
                                riskHistory: [RiskResult],
                                inhalerLog: [InhalerLogEntry],
                                medications: [Medication],
                                dateRange: ClosedRange<Date>) -> Data {

        let pageWidth: CGFloat = 612, pageHeight: CGFloat = 792 // US Letter
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight))

        return renderer.pdfData { context in
            context.beginPage()
            var y: CGFloat = 40

            y = drawTitle("AsthmaGuard AI — Summary Report", y: y)
            y = drawText("Generated: \(formatted(Date()))", y: y, font: .systemFont(ofSize: 10), color: .gray)
            y = drawText("Report period: \(formatted(dateRange.lowerBound)) – \(formatted(dateRange.upperBound))", y: y, font: .systemFont(ofSize: 10), color: .gray)
            y += 12

            y = drawSectionHeader("Patient", y: y)
            y = drawText("Name: \(profile.name.isEmpty ? "—" : profile.name)", y: y)
            y = drawText("Asthma severity: \(profile.asthmaSeverity.rawValue)", y: y)
            y = drawText("Known triggers: \(profile.knownTriggers.joined(separator: ", "))", y: y)
            y += 12

            let filteredHistory = riskHistory.filter { dateRange.contains($0.timestamp) }
            y = drawSectionHeader("Risk Events (\(filteredHistory.count))", y: y)
            let byLevel = Dictionary(grouping: filteredHistory, by: { $0.riskLevel })
            for level in RiskLevel.allCases {
                let count = byLevel[level]?.count ?? 0
                y = drawText("\(level.label): \(count)", y: y)
            }
            y += 12

            let filteredLog = inhalerLog.filter { dateRange.contains($0.timestamp) }
            y = drawSectionHeader("Rescue Inhaler Use (\(filteredLog.count) events)", y: y)
            let totalPuffs = filteredLog.reduce(0) { $0 + $1.puffsTaken }
            y = drawText("Total puffs logged: \(totalPuffs)", y: y)
            let alertTriggered = filteredLog.filter { $0.triggeredByAppAlert }.count
            y = drawText("Used following an app alert: \(alertTriggered)", y: y)
            y += 12

            y = drawSectionHeader("Active Medications", y: y)
            for med in medications where med.isActive {
                y = drawText("\(med.name) — \(med.type.rawValue), \(med.dosage)", y: y)
            }
            y += 20

            y = drawText(AppCopy.disclaimer, y: y, font: .italicSystemFont(ofSize: 9), color: .gray)

            func drawTitle(_ text: String, y: CGFloat) -> CGFloat {
                draw(text, y: y, font: .boldSystemFont(ofSize: 18))
            }
            func drawSectionHeader(_ text: String, y: CGFloat) -> CGFloat {
                draw(text, y: y, font: .boldSystemFont(ofSize: 13))
            }
            func drawText(_ text: String, y: CGFloat, font: UIFont = .systemFont(ofSize: 11), color: UIColor = .black) -> CGFloat {
                draw(text, y: y, font: font, color: color)
            }
            func draw(_ text: String, y: CGFloat, font: UIFont, color: UIColor = .black) -> CGFloat {
                let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color]
                let rect = CGRect(x: 40, y: y, width: pageWidth - 80, height: 400)
                text.draw(in: rect, withAttributes: attributes)
                let height = (text as NSString).boundingRect(
                    with: CGSize(width: pageWidth - 80, height: .greatestFiniteMagnitude),
                    options: .usesLineFragmentOrigin, attributes: attributes, context: nil).height
                return y + height + 6
            }
        }
    }

    private static func formatted(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}
