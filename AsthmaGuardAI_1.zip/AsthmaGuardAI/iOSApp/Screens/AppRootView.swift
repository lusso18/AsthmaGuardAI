import SwiftUI

/// Simple state-machine navigation for onboarding, matching the screen flow:
/// Welcome → Profile → Emergency Contacts → Medication → HealthKit → Dashboard
enum AppScreen {
    case welcome, profile, emergencyContacts, medication, healthKitPermission, dashboard
}

final class AppCoordinator: ObservableObject {
    @Published var currentScreen: AppScreen
    @Published var onboardingComplete: Bool

    init() {
        let complete = UserDefaults.standard.bool(forKey: "onboardingComplete")
        onboardingComplete = complete
        currentScreen = complete ? .dashboard : .welcome
    }

    func advance(to screen: AppScreen) {
        currentScreen = screen
    }

    func completeOnboarding() {
        onboardingComplete = true
        UserDefaults.standard.set(true, forKey: "onboardingComplete")
        currentScreen = .dashboard
    }
}

struct AppRootView: View {
    @StateObject private var coordinator = AppCoordinator()

    var body: some View {
        Group {
            switch coordinator.currentScreen {
            case .welcome:
                WelcomeView(coordinator: coordinator)
            case .profile:
                ProfileSetupView(coordinator: coordinator)
            case .emergencyContacts:
                EmergencyContactSetupView(coordinator: coordinator)
            case .medication:
                MedicationSetupView(coordinator: coordinator)
            case .healthKitPermission:
                HealthKitPermissionView(coordinator: coordinator)
            case .dashboard:
                DashboardView()
            }
        }
    }
}
