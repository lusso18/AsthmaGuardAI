import HealthKit
import Combine

/// Reads heart rate, respiratory rate, SpO2, resting heart rate, HRV, sleep,
/// and step count — all with user permission via standard HealthKit
/// authorization. Note: SpO2 and respiratory rate are periodic, not
/// continuous (see project README for the full explanation of platform
/// limits). This manager is shared conceptually between iOS and watchOS;
/// each target has its own instance since HKHealthStore is not shared across
/// processes.
final class HealthKitManager: ObservableObject {

    static let shared = HealthKitManager()
    private let store = HKHealthStore()

    @Published var latestSpO2: Double?
    @Published var latestRespiratoryRate: Double?
    @Published var latestHeartRate: Double?
    @Published var restingHeartRate: Double?
    @Published var latestHRV: Double?              // SDNN, ms
    @Published var sleepQualityScore: Double?       // 0-1, naive estimate
    @Published var stepCountToday: Double?
    @Published var authorized = false

    private var readTypes: Set<HKObjectType> {
        var types: Set<HKObjectType> = []
        for id: HKQuantityTypeIdentifier in [.oxygenSaturation, .respiratoryRate, .heartRate,
                                              .restingHeartRate, .heartRateVariabilitySDNN, .stepCount] {
            if let t = HKQuantityType.quantityType(forIdentifier: id) { types.insert(t) }
        }
        if let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) {
            types.insert(sleep)
        }
        return types
    }

    func requestAuthorization(completion: @escaping (Bool) -> Void) {
        guard HKHealthStore.isHealthDataAvailable() else { completion(false); return }
        store.requestAuthorization(toShare: [], read: readTypes) { [weak self] success, _ in
            DispatchQueue.main.async {
                self?.authorized = success
                completion(success)
            }
            if success { self?.startObservingAll() }
        }
    }

    /// One-shot "Check My Breathing" pull — grabs the freshest available
    /// sample of each vital rather than waiting for the next observer fire.
    func fetchSnapshot(completion: @escaping (VitalsSnapshot) -> Void) {
        var snapshot = VitalsSnapshot()
        let group = DispatchGroup()

        func fetch(_ identifier: HKQuantityTypeIdentifier, unit: HKUnit, assign: @escaping (Double) -> Void) {
            guard let type = HKQuantityType.quantityType(forIdentifier: identifier) else { return }
            group.enter()
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
            let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1, sortDescriptors: [sort]) { _, samples, _ in
                if let sample = samples?.first as? HKQuantitySample {
                    assign(sample.quantity.doubleValue(for: unit))
                }
                group.leave()
            }
            store.execute(query)
        }

        fetch(.oxygenSaturation, unit: .percent()) { snapshot.spo2 = $0 }
        fetch(.heartRate, unit: HKUnit.count().unitDivided(by: .minute())) { snapshot.heartRate = $0 }
        fetch(.respiratoryRate, unit: HKUnit.count().unitDivided(by: .minute())) { snapshot.respiratoryRate = $0 }
        fetch(.restingHeartRate, unit: HKUnit.count().unitDivided(by: .minute())) { snapshot.restingHeartRate = $0 }
        fetch(.heartRateVariabilitySDNN, unit: .secondUnit(with: .milli)) { snapshot.heartRateVariability = $0 }
        fetch(.stepCount, unit: .count()) { snapshot.stepCountToday = $0 }

        group.notify(queue: .main) {
            completion(snapshot)
        }
    }

    private func startObservingAll() {
        observeQuantity(.oxygenSaturation, unit: .percent()) { [weak self] in self?.latestSpO2 = $0 }
        observeQuantity(.respiratoryRate, unit: HKUnit.count().unitDivided(by: .minute())) { [weak self] in self?.latestRespiratoryRate = $0 }
        observeQuantity(.heartRate, unit: HKUnit.count().unitDivided(by: .minute())) { [weak self] in self?.latestHeartRate = $0 }
        observeQuantity(.restingHeartRate, unit: HKUnit.count().unitDivided(by: .minute())) { [weak self] in self?.restingHeartRate = $0 }
        observeQuantity(.heartRateVariabilitySDNN, unit: .secondUnit(with: .milli)) { [weak self] in self?.latestHRV = $0 }
        observeQuantity(.stepCount, unit: .count()) { [weak self] in self?.stepCountToday = $0 }
    }

    private func observeQuantity(_ identifier: HKQuantityTypeIdentifier, unit: HKUnit, onValue: @escaping (Double) -> Void) {
        guard let type = HKQuantityType.quantityType(forIdentifier: identifier) else { return }
        let observer = HKObserverQuery(sampleType: type, predicate: nil) { [weak self] _, completionHandler, _ in
            defer { completionHandler() }
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
            let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1, sortDescriptors: [sort]) { _, samples, _ in
                guard let sample = samples?.first as? HKQuantitySample else { return }
                DispatchQueue.main.async { onValue(sample.quantity.doubleValue(for: unit)) }
            }
            self?.store.execute(query)
        }
        store.execute(observer)
        store.enableBackgroundDelivery(for: type, frequency: .immediate) { _, _ in }
    }
}
