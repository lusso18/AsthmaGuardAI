import UserNotifications
import UIKit

/// Handles local notification permission plus (Phase 2) registering the
/// device token for Firebase Cloud Messaging so caregivers can be notified
/// server-side even when the patient's app is closed.
final class PushNotificationService: NSObject, UNUserNotificationCenterDelegate {

    static let shared = PushNotificationService()

    func requestPermission(completion: @escaping (Bool) -> Void) {
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            DispatchQueue.main.async {
                if granted { UIApplication.shared.registerForRemoteNotifications() }
                completion(granted)
            }
        }
    }

    func didRegisterForRemoteNotifications(deviceToken: Data) {
        let tokenString = deviceToken.map { String(format: "%02x", $0) }.joined()
        // TODO Phase 2: send tokenString to your backend / Firebase Messaging
        // so it can be associated with this user and used for caregiver pushes.
        _ = tokenString
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                 willPresent notification: UNNotification,
                                 withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .badge])
    }
}
