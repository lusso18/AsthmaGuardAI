# AsthmaGuard AI

Full source drop matching the concept doc's folder structure and build
phases. This is Swift source only — you'll assemble it into an Xcode project
(it isn't a pre-built `.xcodeproj`, since that has to be created in Xcode
itself).

## ⚠️ Safety framing (read before shipping anything)
Every risk message in this app comes from `Shared/Constants/AppConstants.swift`
→ `AppCopy`. It always says **"possible symptoms"**, never "you are having an
asthma attack" or any other diagnostic claim. Keep it that way — this is what
keeps the app in "personal wellness tool" territory rather than "unregulated
medical device." If you ever plan to market this publicly (Phase 4), you'll
need real clinical validation and likely FDA engagement — the code here is a
prototype, not something to ship to strangers as-is.

## Folder structure
```
AsthmaGuardAI/
├── iOSApp/
│   ├── Screens/           (Welcome → Profile → Emergency → Medication →
│   │                        HealthKit → Dashboard, plus Check/Result/
│   │                        History/Settings/InhalerLog)
│   ├── Health/             HealthKitManager (extended: HRV, sleep, steps)
│   ├── RiskEngine/          BreathingCheckViewModel (MVVM glue)
│   ├── Medication/          MedicationStore (reminders + logging)
│   ├── Emergency/           EmergencyContactManager (SMS/call/location)
│   ├── Reports/             PDFReportGenerator (PDFKit)
│   └── PhoneConnectivityManager.swift  (receives watch alerts)
├── WatchApp/
│   ├── WatchScreens/        WatchDashboardView (quick-check)
│   ├── WatchHealth/         WatchHealthKitManager
│   └── WatchAlerts/         WatchAlarmController, WatchConnectivityManager
├── Backend/
│   ├── Firebase/            FirebaseService (stub — add SDK to wire it up)
│   ├── Notifications/       PushNotificationService (local + FCM token reg)
│   ├── AI/                  AIAssistantService (calls YOUR backend, not
│   │                        OpenAI directly — see security note in file)
│   └── Environment/         EnvironmentalDataService (weather/pollen/AQI
│                            placeholders for Phase 3)
└── Shared/
    ├── Models/               UserProfile, Medication, EmergencyContact,
    │                        RiskModels (RiskLevel, SymptomCheck, RiskResult,
    │                        VitalsSnapshot, EnvironmentalContext)
    ├── RiskScoring/          RiskScoringEngine (combines symptoms + vitals +
    │                        environment → RiskResult)
    ├── Constants/            AppConstants + AppCopy (safe wording)
    └── PersistenceStore.swift (local JSON store — swap for Firestore/
                               Supabase in Phase 2 without touching call sites)
```

## Xcode setup
1. New Project → iOS → App, then File → New Target → watchOS → Watch App,
   choosing "based on existing iOS app" so they're paired.
2. Drag all `Shared/*` files into **both** targets (check both target
   membership boxes in the File Inspector).
3. Drag `iOSApp/*` files into the iOS target only, `WatchApp/*` into the
   watch target only, `Backend/*` into the iOS target (and the watch target
   too if you want AI/weather calls to work from the watch directly).
4. Capabilities to add:
   - iOS target: HealthKit, Background Modes (HealthKit + Remote
     notifications), Push Notifications, WatchConnectivity (automatic once
     you `import WatchConnectivity`).
   - Watch target: same HealthKit + WatchConnectivity capabilities.
5. `Info.plist` additions (iOS target): `NSHealthShareUsageDescription`,
   `NSHealthUpdateUsageDescription`, `NSLocationWhenInUseUsageDescription`
   (for emergency-contact location sharing), `NSContactsUsageDescription` if
   you later let people pick contacts from their address book.
6. Add Firebase via Swift Package Manager
   (`https://github.com/firebase/firebase-ios-sdk`) when you're ready to wire
   up `FirebaseService` — pick `FirebaseAuth`, `FirebaseFirestore`,
   `FirebaseMessaging`.
7. For the AI assistant: **do not** put your OpenAI key in the app. Stand up
   a small backend (Firebase Cloud Function or Supabase Edge Function) that
   holds the key and proxies to OpenAI's chat completions endpoint, and point
   `AIAssistantService.backendEndpoint` at that.
8. Apply for the Critical Alerts entitlement from Apple if you want
   emergency-level notifications to bypass Silent/Focus mode — this is a
   manual approval process through Apple Developer support.

## Caregiver notifications (Firebase Cloud Function)
`Backend/Firebase/functions/index.js` is a real, deployable Cloud Function —
not a stub. It listens for new documents at
`users/{userId}/riskHistory/{resultId}` and pushes an FCM notification to any
caregiver who opted into that risk level. This is deliberately server-side
(Firestore trigger) rather than a direct call from the patient's phone,
because a phone that just detected a high-risk event is exactly the device
most likely to be locked, low on battery, or losing connectivity — you don't
want caregiver paging to depend on it staying online.

To deploy:
```
cd Backend/Firebase/functions
npm install
firebase deploy --only functions
```
You'll also need `firebase init firestore` at the project root and Firestore
security rules that let a user write their own `riskHistory` and read/write
their own `caregivers` subcollection, plus `firebase init functions` if you
haven't already set up a Functions directory in your Firebase project — this
`functions/` folder can replace the one it generates.

`iOSApp/Screens/CaregiverLinkView.swift` is what the caregiver (not the
patient) opens on their own device — once you add FirebaseMessaging, it
registers their FCM token via the `registerCaregiverToken` callable function,
so the patient's phone never stores a caregiver's token directly.

## Baseline auto-calibration
`iOSApp/Health/BaselineLearningEngine.swift` replaces manual baseline entry
with numbers learned from the person's own HealthKit history:
- **Resting heart rate** — median of HealthKit's daily `restingHeartRate`
  samples over the last 21 days.
- **Respiratory rate baseline** — median of `respiratoryRate` samples that
  overlap sleep-analysis "asleep" windows over the same period (this is
  intentionally restricted to sleep, since that's the only time respiratory
  rate is reliably captured — see the platform limits note above).

It only overwrites a manually-entered value once there's a configurable
minimum sample count (default 5), so a couple of noisy readings won't quietly
change what triggers an alarm. Trigger it manually via the "Auto-Calibrate
from Health Data" button in Settings, or schedule it weekly with
`BaselineRefreshScheduler` (see that file for the two lines to add to your
App struct's `init()`, plus the `Info.plist` key it needs).

## Known platform limits worth remembering while building Phase 2/3
- No true continuous background SpO2 sampling — HealthKit gives periodic
  readings from Series 6+, more frequent during sleep.
- Real-time waking respiratory rate isn't a standard HealthKit stream;
  Apple's own respiratory rate mostly comes from sleep analysis.
- Sending SMS or making a phone call cannot be done silently by the app —
  `MFMessageComposeViewController` and `tel://` both require the user to tap
  Send/Call themselves. Server-side caregiver push (via Firebase) is the
  reliable path for alerts that don't depend on the user's own phone acting.
