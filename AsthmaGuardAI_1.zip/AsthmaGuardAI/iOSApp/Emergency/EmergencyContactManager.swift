import Foundation
import CoreLocation
import MessageUI

/// Handles notifying caregivers/emergency contacts and the "Call 911" button.
/// Actual SMS sending on iOS requires presenting `MFMessageComposeViewController`
/// (user must tap send — Apple does not allow silently sending SMS on someone's
/// behalf), so this is wired for that flow. Calls likewise open the system
/// dialer via `tel://` — the user places the call, the app cannot dial for them.
final class EmergencyContactManager: NSObject, ObservableObject, CLLocationManagerDelegate {

    @Published var contacts: [EmergencyContact] = []
    @Published var lastKnownLocation: CLLocation?

    private let persistence = PersistenceStore.shared
    private let locationManager = CLLocationManager()

    override init() {
        super.init()
        contacts = persistence.loadEmergencyContacts()
        locationManager.delegate = self
    }

    func addContact(_ contact: EmergencyContact) {
        contacts.append(contact)
        persistence.saveEmergencyContacts(contacts)
    }

    func removeContact(_ contact: EmergencyContact) {
        contacts.removeAll { $0.id == contact.id }
        persistence.saveEmergencyContacts(contacts)
    }

    func requestLocationPermission() {
        locationManager.requestWhenInUseAuthorization()
    }

    func refreshLocation() {
        locationManager.requestLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        lastKnownLocation = locations.last
    }

    /// Builds the SMS body for a high-risk/emergency alert. Caller is
    /// responsible for presenting `MFMessageComposeViewController` with this
    /// body and the contact's phone number — the user taps Send themselves.
    func alertMessageBody(for result: RiskResult, userName: String) -> String {
        var body = "\(userName) may be experiencing asthma symptoms (\(result.riskLevel.label) risk) via AsthmaGuard AI."
        if let loc = lastKnownLocation {
            body += " Location: https://maps.apple.com/?ll=\(loc.coordinate.latitude),\(loc.coordinate.longitude)"
        }
        return body
    }

    /// Returns a `tel://` URL for the system dialer — opening it still
    /// requires the user (or a Siri Shortcut they've set up) to confirm.
    func emergencyCallURL(number: String = "911") -> URL? {
        URL(string: "tel://\(number)")
    }

    func contactsToNotify(for level: RiskLevel) -> [EmergencyContact] {
        switch level {
        case .high:
            return contacts.filter { $0.notifyOnHighRisk }
        case .emergency:
            return contacts.filter { $0.notifyOnHighRisk || $0.notifyOnEmergency }
        default:
            return []
        }
    }
}
