import Foundation

/// Lightweight local JSON persistence for MVP. Swap the storage calls inside
/// each method for Firebase Firestore / Supabase calls in Phase 2 without
/// changing any call sites elsewhere in the app.
final class PersistenceStore {
    static let shared = PersistenceStore()
    private let defaults = UserDefaults.standard

    private enum Key: String {
        case profile, medications, emergencyContacts, inhalerLog, riskHistory
    }

    // MARK: - Profile
    func loadProfile() -> UserProfile {
        load(.profile) ?? UserProfile()
    }
    func saveProfile(_ profile: UserProfile) {
        save(profile, key: .profile)
    }

    // MARK: - Medications
    func loadMedications() -> [Medication] {
        load(.medications) ?? []
    }
    func saveMedications(_ meds: [Medication]) {
        save(meds, key: .medications)
    }

    // MARK: - Emergency Contacts
    func loadEmergencyContacts() -> [EmergencyContact] {
        load(.emergencyContacts) ?? []
    }
    func saveEmergencyContacts(_ contacts: [EmergencyContact]) {
        save(contacts, key: .emergencyContacts)
    }

    // MARK: - Inhaler Log
    func loadInhalerLog() -> [InhalerLogEntry] {
        load(.inhalerLog) ?? []
    }
    func saveInhalerLog(_ entries: [InhalerLogEntry]) {
        save(entries, key: .inhalerLog)
    }
    func appendInhalerLogEntry(_ entry: InhalerLogEntry) {
        var current = loadInhalerLog()
        current.append(entry)
        saveInhalerLog(current)
    }

    // MARK: - Risk History
    func loadRiskHistory() -> [RiskResult] {
        load(.riskHistory) ?? []
    }
    func appendRiskResult(_ result: RiskResult) {
        var current = loadRiskHistory()
        current.append(result)
        // Keep last 500 to avoid unbounded growth in UserDefaults.
        if current.count > 500 { current.removeFirst(current.count - 500) }
        save(current, key: .riskHistory)
    }

    // MARK: - Generic helpers
    private func load<T: Decodable>(_ key: Key) -> T? {
        guard let data = defaults.data(forKey: key.rawValue) else { return nil }
        return try? JSONDecoder().decode(T.self, from: data)
    }
    private func save<T: Encodable>(_ value: T, key: Key) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        defaults.set(data, forKey: key.rawValue)
    }
}
