import Foundation
import UserNotifications

/// Manages medications, schedules local reminders for controller meds, and
/// logs rescue inhaler use.
final class MedicationStore: ObservableObject {

    @Published var medications: [Medication] = []
    @Published var inhalerLog: [InhalerLogEntry] = []

    private let persistence = PersistenceStore.shared

    init() {
        medications = persistence.loadMedications()
        inhalerLog = persistence.loadInhalerLog()
    }

    func addMedication(_ medication: Medication) {
        medications.append(medication)
        persistence.saveMedications(medications)
        if medication.type == .controllerInhaler || medication.type == .oral {
            scheduleReminders(for: medication)
        }
    }

    func removeMedication(_ medication: Medication) {
        medications.removeAll { $0.id == medication.id }
        persistence.saveMedications(medications)
        cancelReminders(for: medication)
    }

    func logInhalerUse(medication: Medication, puffs: Int = 1, fromAlert: Bool = false, riskLevel: RiskLevel? = nil, notes: String = "") {
        let entry = InhalerLogEntry(
            medicationID: medication.id,
            puffsTaken: puffs,
            triggeredByAppAlert: fromAlert,
            associatedRiskLevel: riskLevel?.label,
            notes: notes)
        inhalerLog.append(entry)
        persistence.saveInhalerLog(inhalerLog)
    }

    /// Flags if a controller medication hasn't been logged/reminded-acknowledged
    /// recently — used to drive "missed dose" alerts.
    func missedDoseMedications(within days: Int = 1) -> [Medication] {
        let cutoff = Calendar.current.date(byAdding: .day, value: -days, to: Date()) ?? Date()
        return medications.filter { med in
            guard med.type == .controllerInhaler || med.type == .oral, med.isActive else { return false }
            let recentLogs = inhalerLog.filter { $0.medicationID == med.id && $0.timestamp > cutoff }
            return recentLogs.isEmpty
        }
    }

    private func scheduleReminders(for medication: Medication) {
        for (index, time) in medication.reminderTimes.enumerated() {
            let content = UNMutableNotificationContent()
            content.title = "Medication Reminder"
            content.body = "Time to take \(medication.name) (\(medication.dosage))"
            content.sound = .default

            let trigger = UNCalendarNotificationTrigger(dateMatching: time, repeats: true)
            let request = UNNotificationRequest(
                identifier: "med-\(medication.id.uuidString)-\(index)",
                content: content, trigger: trigger)
            UNUserNotificationCenter.current().add(request)
        }
    }

    private func cancelReminders(for medication: Medication) {
        let ids = medication.reminderTimes.indices.map { "med-\(medication.id.uuidString)-\($0)" }
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids)
    }
}
