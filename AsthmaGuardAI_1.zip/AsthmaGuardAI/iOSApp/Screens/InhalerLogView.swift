import SwiftUI

struct InhalerLogView: View {
    @ObservedObject var store: MedicationStore
    @State private var selectedMedication: Medication?
    @State private var puffs = 1

    private var rescueMeds: [Medication] { store.medications.filter { $0.type == .rescueInhaler } }

    var body: some View {
        NavigationView {
            Form {
                if !rescueMeds.isEmpty {
                    Section("Log a Dose") {
                        Picker("Medication", selection: $selectedMedication) {
                            ForEach(rescueMeds) { med in
                                Text(med.name).tag(Optional(med))
                            }
                        }
                        Stepper("Puffs: \(puffs)", value: $puffs, in: 1...10)
                        Button("Log Now") {
                            guard let med = selectedMedication ?? rescueMeds.first else { return }
                            store.logInhalerUse(medication: med, puffs: puffs)
                        }
                    }
                }

                Section("History") {
                    ForEach(store.inhalerLog.sorted(by: { $0.timestamp > $1.timestamp })) { entry in
                        VStack(alignment: .leading) {
                            HStack {
                                Text("\(entry.puffsTaken) puff(s)").bold()
                                if entry.triggeredByAppAlert {
                                    Text("via alert").font(.caption2).foregroundColor(.orange)
                                }
                                Spacer()
                                Text(entry.timestamp, style: .relative).font(.caption).foregroundColor(.secondary)
                            }
                            if let level = entry.associatedRiskLevel {
                                Text("Risk level at the time: \(level)").font(.caption).foregroundColor(.secondary)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Inhaler Log")
            .onAppear {
                if selectedMedication == nil { selectedMedication = rescueMeds.first }
            }
        }
    }
}
